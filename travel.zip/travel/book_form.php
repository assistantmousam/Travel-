<?php
// Database connection
$connection = mysqli_connect('localhost', 'root', '', 'book_db');

// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Create the database
$createDatabaseQuery = "CREATE DATABASE IF NOT EXISTS book_db";
if (mysqli_query($connection, $createDatabaseQuery)) {
    echo "Database created successfully<br>";
} else {
    echo "Error creating database: " . mysqli_error($connection) . "<br>";
}

// Select the database
mysqli_select_db($connection, 'book_db');

// Create the table
$createTableQuery = "CREATE TABLE IF NOT EXISTS book_form (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    address VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    guests INT NOT NULL,
    arrivals DATE NOT NULL,
    leaving DATE NOT NULL
)";
if (mysqli_query($connection, $createTableQuery)) {
    echo "Table created successfully<br>";
} else {
    echo "Error creating table: " . mysqli_error($connection) . "<br>";
}

// Close the initial database connection
mysqli_close($connection);

// Form processing with validation
if (isset($_POST['send'])) {
    // Reconnect to the database
    $connection = mysqli_connect('localhost', 'root', '', 'book_db');

    // Check connection
    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Function to validate email format
    function isValidEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL);
    }

    // Function to validate phone number format
    function isValidPhone($phone) {
        // Basic validation for a 10-digit phone number
        return preg_match("/^[0-9]{10}$/", $phone);
    }

    // Basic input validation
    $name = mysqli_real_escape_string($connection, $_POST['name']);
    $email = mysqli_real_escape_string($connection, $_POST['email']);
    $phone = mysqli_real_escape_string($connection, $_POST['phone']);
    $address = mysqli_real_escape_string($connection, $_POST['address']);
    $location = mysqli_real_escape_string($connection, $_POST['location']);
    $guests = mysqli_real_escape_string($connection, $_POST['guests']);
    $arrivals = mysqli_real_escape_string($connection, $_POST['arrivals']);
    $leaving = mysqli_real_escape_string($connection, $_POST['leaving']);

    // Additional validation
    if (empty($name) || empty($email) || empty($phone) || empty($address) || empty($location) || empty($guests) || empty($arrivals) || empty($leaving)) {
        die("Please fill in all the fields.");
    }

    if (!isValidEmail($email)) {
        die("Invalid email format.");
    }

    if (!isValidPhone($phone)) {
        die("Invalid phone number format. Please enter a 10-digit number.");
    }

    // Example date format (adjust based on your needs)
    $dateFormat = "Y-m-d";

    if (!DateTime::createFromFormat($dateFormat, $arrivals) || !DateTime::createFromFormat($dateFormat, $leaving)) {
        die("Invalid date format. Please use the format: " . $dateFormat);
    }

    // Insert data into the database
    $insertDataQuery = "INSERT INTO book_form (name, email, phone, address, location, guests, arrivals, leaving) 
                        VALUES ('$name', '$email', '$phone', '$address', '$location', '$guests', '$arrivals', '$leaving')";

    if (mysqli_query($connection, $insertDataQuery)) {
        echo "Data inserted successfully<br>";
        header('Location: book.php');
    } else {
        echo "Error inserting data: " . mysqli_error($connection) . "<br>";
    }

    // Close the database connection
    mysqli_close($connection);
} else {
    echo 'Something went wrong, please try again.';
}
?>
