
let menu = document.querySelector('#menu-btn');
let navbar = document.querySelector('.header .navbar');


function updateMenuAndNavbar() {
    let scrollY = window.scrollY || window.pageYOffset;

    
    if (scrollY > 200) {
        menu.classList.add('custom-class');
     
    } else {
        menu.classList.remove('custom-class');
      
    }
}


menu.onclick = () => {
    menu.classList.toggle('fa-times');
    navbar.classList.toggle('active');
};

window.onscroll = () => {
    updateMenuAndNavbar();
};


updateMenuAndNavbar();

var swiper = new Swiper(".home-slider", {
    loop:true,

    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });

  var swiper = new Swiper(".row", {
    loop:true,
    slidesPerView:3,
    spaceBetween:30,
    pagination: {
      el: ".swiper-pagination",
      type: "progressbar",
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });
  document.addEventListener('DOMContentLoaded', function () {
    var swiper = new Swiper(".reviews-slider", {
        loop: true,
        slidesPerView: 1,
        spaceBetween: 30,
        pagination: {
            el: ".swiper-pagination",
            type: "progressbar",
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
    });
});
  
  var swiper = new Swiper(".reviews-slider", {
   
    slidesPerView: 3,
    spaceBetween: 30,
    slidePerGroup:3,
    loop: true,
    loopfillGroupWithBlank:true,
    
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });
  // va
  var swiper = new Swiper(".slide-content", {
   
    slidesPerView: 3,
    spaceBetween: 30,
    slidePerGroup:3,
    loop: true,
    loopfillGroupWithBlank:true,
    
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });

 
  

  